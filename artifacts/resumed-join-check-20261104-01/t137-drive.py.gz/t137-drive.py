"""One-off finite evidence operator; not an adopted workflow."""
import hashlib,json,subprocess,sys
from pathlib import Path
r=Path('artifacts/resumed-join-check-20261104-01');pin=sys.argv[1];assert hashlib.sha256((r/'request-freeze.json').read_bytes()).hexdigest()==pin
run=lambda args:subprocess.run(args,check=True)
for n in [1,2,3]:
 run(['uv','run','python','tmp/t137-call.py','J2',str(n),pin])
 if n in [1,3]:
  v=2 if n==1 else 3;run(['uv','run','python','tmp/t137-publish.py',str(v)]);run(['uv','run','python','tmp/t137-review-check.py',str(v),'HR-036'])
  with Path(f'tmp/t137-register-v{v}.json').open('w') as out:subprocess.run(['uv','run','globe','review','register',f'docs/review-packets/HR-036-v{v}.json'],check=True,stdout=out)
  if n==1:
   proof=dict(case='J2',registered_successfully=True,first_result_sha256=hashlib.sha256((r/'J2/call-1/result.json').read_bytes()).hexdigest(),packet='docs/review-packets/HR-036-v2.json',packet_sha256=hashlib.sha256(Path('docs/review-packets/HR-036-v2.json').read_bytes()).hexdigest(),checks=str(r/'review-v2-checks.json'))
   with (r/'J2/first-actual-publication.json').open('x') as f:json.dump(proof,f,indent=2)
   print('First actual published HR036v2; fixed remaining two repetitions next with fresh inbox checks.',flush=True)
print('Three fixed observations terminal; no further model calls.',flush=True)
